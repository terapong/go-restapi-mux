# go-restapi-mux
Tutorial Golang membuat REST API menggunakan gorilla/mux, gorm dan database MySQL

Youtube: [Golang REST API with Mux, Gorm, MySQL](https://youtu.be/dENoPS8aRL8)
